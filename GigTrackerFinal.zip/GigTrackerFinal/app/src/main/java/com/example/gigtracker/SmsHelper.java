package com.example.gigtracker;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

import java.util.List;

/** Keeps the SMS settings and sends the upcoming-event reminder texts. */
public final class SmsHelper {
    private static final String PREFS_NAME = "gigtracker_prefs";
    private static final String KEY_ENABLED = "sms_enabled";
    private static final String KEY_PHONE = "phone_number";
    private static final String KEY_PROMPTED = "sms_prompted";

    /** An event counts as "upcoming" when it is this many days away or fewer. */
    private static final int ALERT_WINDOW_DAYS = 3;

    private SmsHelper() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    /** True when the user has granted the SEND_SMS runtime permission. */
    public static boolean hasPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Notifications run only if permission was granted AND the user chose to turn them on. */
    public static boolean isEnabled(Context context) {
        return hasPermission(context) && prefs(context).getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    public static String getPhoneNumber(Context context) {
        return prefs(context).getString(KEY_PHONE, "");
    }

    public static void setPhoneNumber(Context context, String phoneNumber) {
        prefs(context).edit().putString(KEY_PHONE, phoneNumber).apply();
    }

    /** Whether the permission screen has already been shown once. */
    public static boolean wasPrompted(Context context) {
        return prefs(context).getBoolean(KEY_PROMPTED, false);
    }

    public static void markPrompted(Context context) {
        prefs(context).edit().putBoolean(KEY_PROMPTED, true).apply();
    }

    /** Sends one text message; returns false if notifications are off or sending fails. */
    public static boolean sendMessage(Context context, String phoneNumber, String message) {
        if (!isEnabled(context) || phoneNumber.isEmpty()) {
            return false;
        }
        try {
            // Android 12+ uses the system service; older versions use getDefault().
            SmsManager smsManager = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                    ? context.getSystemService(SmsManager.class)
                    : SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            return true;
        } catch (Exception e) {
            return false; // bad number or no SIM: the rest of the app keeps working
        }
    }

    /** Texts a reminder for each upcoming event that has not been reminded yet; returns the count sent. */
    public static int sendUpcomingEventAlerts(Context context, DatabaseHelper database,
                                              List<Event> events) {
        if (!isEnabled(context)) {
            return 0; // permission denied or switched off: silently skip alerts
        }
        String phoneNumber = getPhoneNumber(context);
        int sentCount = 0;
        for (Event event : events) {
            long days = event.daysUntil();
            boolean isUpcoming = days >= 0 && days <= ALERT_WINDOW_DAYS;
            if (isUpcoming && !event.isNotified()) {
                String message = "GigTracker: " + event.getArtist() + " at " + event.getVenue()
                        + " is " + describeDays(days) + " (" + event.getDate() + ").";
                if (sendMessage(context, phoneNumber, message)) {
                    database.markNotified(event.getId());
                    sentCount++;
                }
            }
        }
        return sentCount;
    }

    private static String describeDays(long days) {
        if (days == 0) {
            return "today";
        }
        return days == 1 ? "tomorrow" : "in " + days + " days";
    }
}
