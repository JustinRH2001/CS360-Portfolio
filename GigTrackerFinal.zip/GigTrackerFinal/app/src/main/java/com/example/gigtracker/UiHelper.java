package com.example.gigtracker;

import android.app.Activity;
import android.content.Intent;
import android.view.View;

import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

/** Small shared helpers so every screen looks and behaves the same way. */
public final class UiHelper {
    private UiHelper() { }

    /** Keeps content clear of the status/navigation bars and paints the app background behind them. */
    public static void applySystemBarInsets(Activity activity) {
        View content = activity.findViewById(android.R.id.content);
        content.setBackgroundColor(ContextCompat.getColor(activity, R.color.bg));
        ViewCompat.setOnApplyWindowInsetsListener(content, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        // Dark background, so use light status-bar icons.
        WindowCompat.getInsetsController(activity.getWindow(), content)
                .setAppearanceLightStatusBars(false);
    }

    /** Opens another screen with the same slide transition everywhere. */
    public static void openScreen(Activity from, Intent intent) {
        from.startActivity(intent);
        from.overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
    }
}
