package com.example.gigtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/** Creates the SQLite database and handles every read/write the app needs. */
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "gigtracker.db";
    private static final int DATABASE_VERSION = 1;

    // Users table: one row per account
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";

    // Events table: one row per concert, owned by a user
    private static final String TABLE_EVENTS = "events";
    private static final String COL_EVENT_ID = "id";
    private static final String COL_EVENT_USER_ID = "user_id";
    private static final String COL_ARTIST = "artist";
    private static final String COL_VENUE = "venue";
    private static final String COL_DATE = "event_date";
    private static final String COL_NOTIFIED = "notified"; // 1 once the SMS reminder was sent

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT UNIQUE NOT NULL, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL)");
        db.execSQL("CREATE TABLE " + TABLE_EVENTS + " ("
                + COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_EVENT_USER_ID + " INTEGER NOT NULL, "
                + COL_ARTIST + " TEXT NOT NULL, "
                + COL_VENUE + " TEXT NOT NULL, "
                + COL_DATE + " TEXT NOT NULL, "
                + COL_NOTIFIED + " INTEGER NOT NULL DEFAULT 0, "
                + "FOREIGN KEY(" + COL_EVENT_USER_ID + ") REFERENCES "
                + TABLE_USERS + "(" + COL_USER_ID + "))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Shell database: simplest safe upgrade is to rebuild the tables.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // ---------------------------------------------------------------- users

    /** Creates an account; returns false if the username is already taken. */
    public boolean addUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD_HASH, hashPassword(password));
        // insert() returns -1 when the UNIQUE username constraint fails
        return getWritableDatabase().insert(TABLE_USERS, null, values) != -1;
    }

    /** Returns the user's id when the credentials match a stored account, otherwise -1. */
    public long authenticateUser(String username, String password) {
        String where = COL_USERNAME + "=? AND " + COL_PASSWORD_HASH + "=?";
        String[] args = {username, hashPassword(password)};
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS, new String[]{COL_USER_ID}, where, args, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getLong(0) : -1;
        }
    }

    /** Passwords are stored as SHA-256 hashes, never as plain text. */
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : bytes) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is not available", e);
        }
    }

    // --------------------------------------------------------------- events

    /** Create: adds a new event for the given user. */
    public boolean addEvent(long userId, String artist, String venue, String date) {
        ContentValues values = new ContentValues();
        values.put(COL_EVENT_USER_ID, userId);
        values.put(COL_ARTIST, artist);
        values.put(COL_VENUE, venue);
        values.put(COL_DATE, date);
        return getWritableDatabase().insert(TABLE_EVENTS, null, values) != -1;
    }

    /** Read: returns every event that belongs to the user, oldest entry first. */
    public List<Event> getEvents(long userId) {
        List<Event> events = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_EVENTS, null, COL_EVENT_USER_ID + "=?",
                new String[]{String.valueOf(userId)}, null, null, COL_EVENT_ID)) {
            while (cursor.moveToNext()) {
                events.add(new Event(
                        cursor.getLong(cursor.getColumnIndexOrThrow(COL_EVENT_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ARTIST)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_VENUE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_DATE)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_NOTIFIED)) == 1));
            }
        }
        return events;
    }

    /** Update: changes an event's date and re-arms its SMS reminder. */
    public boolean updateEventDate(long eventId, String newDate) {
        ContentValues values = new ContentValues();
        values.put(COL_DATE, newDate);
        values.put(COL_NOTIFIED, 0);
        return getWritableDatabase().update(
                TABLE_EVENTS, values, COL_EVENT_ID + "=?", idArgs(eventId)) > 0;
    }

    /** Delete: removes one event. */
    public boolean deleteEvent(long eventId) {
        return getWritableDatabase().delete(
                TABLE_EVENTS, COL_EVENT_ID + "=?", idArgs(eventId)) > 0;
    }

    /** Records that the reminder text was sent so it is never sent twice. */
    public void markNotified(long eventId) {
        ContentValues values = new ContentValues();
        values.put(COL_NOTIFIED, 1);
        getWritableDatabase().update(TABLE_EVENTS, values, COL_EVENT_ID + "=?", idArgs(eventId));
    }

    private String[] idArgs(long id) {
        return new String[]{String.valueOf(id)};
    }
}
