package com.example.gigtracker;

import android.Manifest;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.pm.PackageManager;

/** Permission screen: asks to send SMS reminders and shows the user's choice. */
public class SmsActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    private EditText phoneInput;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        UiHelper.applySystemBarInsets(this);
        SmsHelper.markPrompted(this); // never auto-open this screen again

        phoneInput = findViewById(R.id.etPhone);
        statusText = findViewById(R.id.tvStatus);
        phoneInput.setText(SmsHelper.getPhoneNumber(this));

        findViewById(R.id.btnAllow).setOnClickListener(v -> handleAllow());
        findViewById(R.id.btnDeny).setOnClickListener(v -> handleDeny());
        findViewById(R.id.btnTest).setOnClickListener(v -> sendTestAlert());
        updateStatus();
    }

    /** Saves the phone number, then checks for (or requests) the SEND_SMS permission. */
    private void handleAllow() {
        String phoneNumber = phoneInput.getText().toString().trim();
        if (phoneNumber.isEmpty()) {
            showMessage("Enter a phone number first");
            return;
        }
        SmsHelper.setPhoneNumber(this, phoneNumber);

        if (SmsHelper.hasPermission(this)) {
            SmsHelper.setEnabled(this, true);
            updateStatus();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    /** The user opted out: the rest of the app keeps working without texts. */
    private void handleDeny() {
        SmsHelper.setEnabled(this, false);
        updateStatus();
        showMessage("Reminders are off. Everything else still works.");
    }

    /** Receives the user's answer from the system permission dialog. */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != SMS_PERMISSION_REQUEST_CODE) {
            return;
        }
        boolean granted = grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        SmsHelper.setEnabled(this, granted);
        if (!granted) {
            showMessage("Permission denied. Reminders are off, everything else still works.");
        }
        updateStatus();
    }

    /** Sends a sample text so the user can confirm reminders work. */
    private void sendTestAlert() {
        if (!SmsHelper.isEnabled(this)) {
            showMessage("Turn on SMS reminders first");
            return;
        }
        boolean sent = SmsHelper.sendMessage(this, SmsHelper.getPhoneNumber(this),
                "GigTracker: test alert. Your event reminders are working!");
        showMessage(sent ? "Test text sent" : "Could not send the text");
    }

    private void updateStatus() {
        boolean enabled = SmsHelper.isEnabled(this);
        statusText.setText(enabled ? "Status: Notifications on" : "Status: Notifications off");
        statusText.setTextColor(ContextCompat.getColor(this,
                enabled ? R.color.green : R.color.gray));
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
