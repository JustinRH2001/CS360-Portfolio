package com.example.gigtracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.List;

/** Data screen: shows the user's events as a grid and supports add, edit and delete. */
public class EventsActivity extends AppCompatActivity {
    public static final String EXTRA_USER_ID = "user_id";

    private DatabaseHelper database;
    private long userId;
    private EditText artistInput;
    private EditText venueInput;
    private EditText dateInput;
    private TableLayout eventTable;
    private TextView emptyMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userId = getIntent().getLongExtra(EXTRA_USER_ID, -1);
        if (userId == -1) {
            finish(); // opened without logging in
            return;
        }
        setContentView(R.layout.activity_events);
        UiHelper.applySystemBarInsets(this);

        database = new DatabaseHelper(this);
        artistInput = findViewById(R.id.etArtist);
        venueInput = findViewById(R.id.etVenue);
        dateInput = findViewById(R.id.etDate);
        eventTable = findViewById(R.id.tableEvents);
        emptyMessage = findViewById(R.id.tvEmpty);

        findViewById(R.id.btnAdd).setOnClickListener(v -> addEvent());
        findViewById(R.id.btnSms).setOnClickListener(v -> openSmsSettings());

        // First visit: ask about SMS reminders once, right after login.
        if (!SmsHelper.wasPrompted(this)) {
            openSmsSettings();
        }
    }

    /** Reloads the grid whenever the screen returns (also re-checks reminders after SMS changes). */
    @Override
    protected void onResume() {
        super.onResume();
        if (userId != -1) {
            refreshGrid();
        }
    }

    private void openSmsSettings() {
        UiHelper.openScreen(this, new Intent(this, SmsActivity.class));
    }

    /** Validates the form and inserts a new event. */
    private void addEvent() {
        String artist = artistInput.getText().toString().trim();
        String venue = venueInput.getText().toString().trim();
        String date = dateInput.getText().toString().trim();

        if (artist.isEmpty() || venue.isEmpty()) {
            showMessage("Please enter an artist and a venue");
        } else if (Event.parseDate(date) == null) {
            showMessage("Use a real date in MM/DD/YYYY format");
        } else if (database.addEvent(userId, artist, venue, date)) {
            artistInput.setText("");
            venueInput.setText("");
            dateInput.setText("");
            refreshGrid();
        } else {
            showMessage("Could not save the event");
        }
    }

    /** Rebuilds every data row from the database, then sends any due SMS reminders. */
    private void refreshGrid() {
        List<Event> events = database.getEvents(userId);

        // Keep row 0 (the header) and remove the old data rows.
        eventTable.removeViews(1, eventTable.getChildCount() - 1);
        emptyMessage.setVisibility(events.isEmpty() ? View.VISIBLE : View.GONE);

        LayoutInflater inflater = getLayoutInflater();
        for (int index = 0; index < events.size(); index++) {
            eventTable.addView(buildRow(inflater, events.get(index), index));
        }

        int sentCount = SmsHelper.sendUpcomingEventAlerts(this, database, events);
        if (sentCount > 0) {
            showMessage("Sent " + sentCount + " event reminder text(s)");
        }
    }

    /** Fills one grid row with an event's values and wires up its Edit and Delete buttons. */
    private TableRow buildRow(LayoutInflater inflater, Event event, int index) {
        TableRow row = (TableRow) inflater.inflate(R.layout.row_event, eventTable, false);
        ((TextView) row.findViewById(R.id.tvArtist)).setText(event.getArtist());
        ((TextView) row.findViewById(R.id.tvVenue)).setText(event.getVenue());
        ((TextView) row.findViewById(R.id.tvDate)).setText(event.getDate());

        if (index % 2 == 1) {
            row.setBackgroundColor(ContextCompat.getColor(this, R.color.row_alt)); // zebra striping
        }
        row.findViewById(R.id.btnEdit).setOnClickListener(v -> showEditDialog(event));
        row.findViewById(R.id.btnDelete).setOnClickListener(v -> confirmDelete(event));
        return row;
    }

    /** Update: lets the user change the date of one event. */
    private void showEditDialog(Event event) {
        EditText dateField = new EditText(this);
        dateField.setInputType(InputType.TYPE_CLASS_DATETIME | InputType.TYPE_DATETIME_VARIATION_DATE);
        dateField.setText(event.getDate());
        dateField.setPadding(64, 32, 64, 32);

        new AlertDialog.Builder(this)
                .setTitle("New date for " + event.getArtist())
                .setView(dateField)
                .setPositiveButton("Save", (dialog, which) ->
                        saveNewDate(event, dateField.getText().toString().trim()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveNewDate(Event event, String newDate) {
        if (Event.parseDate(newDate) == null) {
            showMessage("Use a real date in MM/DD/YYYY format");
            return;
        }
        database.updateEventDate(event.getId(), newDate);
        refreshGrid();
    }

    /** Delete: asks first so a stray tap can't remove an event. */
    private void confirmDelete(Event event) {
        new AlertDialog.Builder(this)
                .setTitle("Delete this event?")
                .setMessage(event.getArtist() + " at " + event.getVenue())
                .setPositiveButton("Delete", (dialog, which) -> {
                    database.deleteEvent(event.getId());
                    refreshGrid();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
