package com.example.gigtracker;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Model for one row of the events table. */
public class Event {
    private static final String DATE_PATTERN = "MM/dd/yyyy";

    private final long id;
    private final String artist;
    private final String venue;
    private final String date;
    private final boolean notified;

    public Event(long id, String artist, String venue, String date, boolean notified) {
        this.id = id;
        this.artist = artist;
        this.venue = venue;
        this.date = date;
        this.notified = notified;
    }

    public long getId() { return id; }
    public String getArtist() { return artist; }
    public String getVenue() { return venue; }
    public String getDate() { return date; }
    public boolean isNotified() { return notified; }

    /** Parses MM/DD/YYYY text; returns null when the text is not a real date. */
    public static Date parseDate(String text) {
        if (!text.matches("\\d{2}/\\d{2}/\\d{4}")) {
            return null;
        }
        SimpleDateFormat format = new SimpleDateFormat(DATE_PATTERN, Locale.US);
        format.setLenient(false); // reject dates like 13/45/2026
        try {
            return format.parse(text);
        } catch (ParseException e) {
            return null;
        }
    }

    /** Whole days from today until this event (negative if past, huge if unparsable). */
    public long daysUntil() {
        Date eventDate = parseDate(date);
        if (eventDate == null) {
            return Long.MAX_VALUE;
        }
        // Compare against midnight today so the time of day never changes the result.
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);
        long difference = eventDate.getTime() - today.getTimeInMillis();
        return Math.round(difference / (double) TimeUnit.DAYS.toMillis(1));
    }
}
