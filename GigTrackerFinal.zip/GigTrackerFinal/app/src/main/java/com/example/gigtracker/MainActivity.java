package com.example.gigtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/** Login screen: signs in existing users and creates accounts for new ones. */
public class MainActivity extends AppCompatActivity {
    private static final int MIN_PASSWORD_LENGTH = 4;

    private DatabaseHelper database;
    private EditText usernameInput;
    private EditText passwordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UiHelper.applySystemBarInsets(this);

        database = new DatabaseHelper(this);
        usernameInput = findViewById(R.id.etUsername);
        passwordInput = findViewById(R.id.etPassword);

        findViewById(R.id.btnLogin).setOnClickListener(v -> handleLogin());
        findViewById(R.id.btnCreate).setOnClickListener(v -> handleCreateAccount());
    }

    /** Checks the typed credentials against the users table and opens the events grid. */
    private void handleLogin() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();
        if (!areCredentialsValid(username, password)) {
            return;
        }

        long userId = database.authenticateUser(username, password);
        if (userId == -1) {
            showMessage("Invalid username or password");
            return;
        }

        passwordInput.setText(""); // don't leave the password sitting in the field
        Intent intent = new Intent(this, EventsActivity.class);
        intent.putExtra(EventsActivity.EXTRA_USER_ID, userId);
        UiHelper.openScreen(this, intent);
    }

    /** Saves a brand-new username and password to the users table. */
    private void handleCreateAccount() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();
        if (!areCredentialsValid(username, password)) {
            return;
        }

        if (database.addUser(username, password)) {
            showMessage("Account created. You can log in now.");
        } else {
            showMessage("That username is already taken");
        }
    }

    /** Basic input check shared by login and account creation. */
    private boolean areCredentialsValid(String username, String password) {
        if (username.isEmpty() || password.length() < MIN_PASSWORD_LENGTH) {
            showMessage("Enter a username and a password of at least "
                    + MIN_PASSWORD_LENGTH + " characters");
            return false;
        }
        return true;
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
